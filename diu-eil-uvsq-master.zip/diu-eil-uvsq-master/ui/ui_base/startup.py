from files.ui import *

if __name__ == '__main__':
    root = Root()
    root.mainloop()

