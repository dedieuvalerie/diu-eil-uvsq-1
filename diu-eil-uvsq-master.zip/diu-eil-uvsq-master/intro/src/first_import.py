#!/usr/bin/env python3
# -*- coding: utf-8 -*-

"""Ce module est un exemple d'importation.

"""

import first_script

if __name__ == '__main__':
    print("Dans first-import")

